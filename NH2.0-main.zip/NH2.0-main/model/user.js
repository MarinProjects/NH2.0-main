const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },

  passwordHash: {
    type: String,
    required: true
  },

  role: {
    type: String,
    enum: ['ADMIN', 'READONLY'],
    required: true
  },

  active: {
    type: Boolean,
    default: true
  }
});

module.exports = mongoose.model('User', userSchema);